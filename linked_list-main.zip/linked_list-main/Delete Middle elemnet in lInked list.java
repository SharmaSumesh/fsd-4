public static Node deleteMiddleElement(Node head) {
if(head==null||head.next==null)
{
    head.val = -1;
}
else
{
    Node slow=head,fast = head;
    while(fast.next.next!=null &&fast.next.next.next!=null)
    {
        slow = slow.next;
        fast = fast.next.next;
    }
    Node delete = slow.next;
    slow.next = delete.next;
    delete.next=null;
}
return head;
}






		// return the head of the modified Linked List
    }
