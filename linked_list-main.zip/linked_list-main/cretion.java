package com.company;

public class Main {
   public class Node
    {
        int data;
        Node next;
        Node(int data)
        {
            this.next = null;
            this.data = data;
        }
    }
    static public Node head= null;
    public void addfirst(int data) {
        Node new_node = new Node(data);
        if (head == null) {
            head = new_node;
            return;
        } else {
            new_node.next = head;
            head = new_node;
        }
    }
    public void addlast(int data)
    {
        Node new_node = new Node(data);
        if(head==null)
        {
            head = new_node;
            return;
        }
        Node temp1 = head;
        while (temp1.next!=null)
        {
            temp1 = temp1.next;
        }
        temp1.next = new_node;
    }
    public void addanypos(int data,int pos)
    {
        Node new_node = new Node(data);
        if(head==null)
        {
            head = new_node;
        }
        else if(pos==1)
        {
            new_node.next = head;
            head = new_node;
        }
        else
        {
            Node temp = head;
       for(int i=0;i<(pos-1);i++)
       {
           temp = temp.next;
       }
       new_node.next = temp.next;
       temp.next = new_node;
        }
    }
    public void removefirst()
    {
        if(head==null)
        {
            System.out.println("null");
        }
        else
        {
            Node temp = head;
            temp = temp.next;
            head = temp;
        }
    }
    public void removelast()
    {
        if(head==null)
        {
            System.out.println("null");
        }
        Node temp1 = head;
        Node ptr = temp1.next;
        while (ptr.next!=null)
        {
            temp1 = ptr;
            ptr = ptr.next;
        }
        temp1.next = null;
    }
    public void  removeanypos(int data,int pos)
    {
        Node temp = head;
        Node ptr = head.next;
        for(int i=0;i<(pos-1);i++)
        {
            temp = ptr;
            ptr = ptr.next;
        }
    }
    public void printlist()
    {
        if(head==null)
        {
            System.out.println("null");
        }
        else {
            Node temp = head;
            while (temp.next != null) {
                System.out.println(temp.data + " ");
                temp = temp.next;
            }

        }    }


    public static void main(String[] args) {
        //creation of Lineked list
        Main a  = new Main();
        a.addfirst(1);
        a.addfirst(2);
        a.addfirst(3);
        a.addfirst(4);
        a.printlist();
        System.out.println("after the add last operation");
        a.addlast(7);
        a.addlast(8);
        a.printlist();
        System.out.println("add at spefic pos");
        a.addanypos(9,2);
        a.printlist();
        a.removefirst();
        a.printlist();
        a.removelast();
        a.printlist();
        a.removeanypos(4,3);
        a.printlist();

    }
}
