package com.company;

import java.io.FilterOutputStream;

public class Main {
    //circular Linked list in java
    public class Node
    {
        int data;
        Node next;
        Node (int data)
        {
            this.next = null;
            this.data = data;
        }
    }
    public Node head=null;
    public Node tail=null;
    public void creation(int data)
    {
        Node new_node = new Node(data);
        if(head==null)
        {
            head = new_node;
            tail = new_node;
            new_node.next = tail;
        }
        else
        {
            new_node.next = head;
            head = new_node;
            tail.next = new_node;

        }
    }

    public void addfirst(int data)
    {
        Node new_node = new Node(data);
        if(head==null)
        {
            head = new_node;
            tail= new_node;
            tail.next = new_node;
        }
        else
        {
            new_node.next = head;
            head = new_node;
            tail.next = new_node;
        }
    }
    public void addlast(int data)
    {
        Node new_node = new Node(data);
        if(head==null)
        {
            head = new_node;
            tail= new_node;
            tail.next = new_node;
        }
        else
        {
            tail.next = new_node;
            tail = new_node;
            new_node.next = head;
        }
    }
    public void addanypos(int data,int pos)
    {
        Node new_node = new Node(data);
        if(head==null)
        {
            head = new_node;
            tail= new_node;
            tail.next = new_node;
        }
        else
        {
            Node temp = head;
            for(int i=0;i<(pos-1);i++)
            {
                temp = temp.next;
            }
            new_node.next = temp.next;
            temp.next = new_node;
        }
    }
    public void deletefirst()
    {
        Node temp = head;
        temp = temp.next;
        head = temp;
        tail.next = head;
    }
    public void deletelast()
    {
        Node temp = head;
        Node ptr = temp.next;
        while (ptr.next!=null)
        {
            temp = ptr;
            ptr = ptr.next;
        }
        temp.next = null;
    }
    public void deleteanypos(int pos)
    {
        Node temp = head;
        Node ptr = temp.next;
        for(int i=0;i<(pos-1);i++)
        {
            temp =ptr;
            ptr = temp.next;
        }
        temp.next = ptr.next;
    }
    public void traverse()
    {
        Node temp = head;
        if(head==null)
        {
            System.out.println("empty");
        }
        else
        {
            do {
                System.out.println(temp.data);
                temp = temp.next;
            }
            while (temp!=head);
        }
    }
    public static void main(String[] args) {
        Main  a = new Main();
        a.creation(2);
        a.creation(3);
        a.creation(4);
        a.addfirst(1);
        a.addlast(7);
        a.addanypos(6,1);
        a.traverse();
        System.out.println("after the delete operations");
        a.deletefirst();
       a.deleteanypos(3);
        a.traverse();
    }
}
