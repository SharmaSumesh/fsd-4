class GfG
{
    boolean isCircular(Node head)
    {
	if(head==null)
	{
	    return true;
	}
	Node temp = head;
	while(temp!=null)
	{
	    if(temp.next==head)
	    {
	        return true;
	    }
	    temp = temp.next;
	    
	    
	       
	    }
	     return false;
	}
    
}
