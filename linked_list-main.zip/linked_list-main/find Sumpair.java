    static boolean sumapair(Node head, int x)
    {
        Node first = head;
        Node second = head;
        while(second.next!=null)
        {
            second = second.next;
            boolean found = false;
            while (first!=second && second.next!=first)
            {
                if(first.data+second.data==x)
                {
                    System.out.println(first.data+" "+second.data);
                }
                else
                {
                    if(first.data+second.data<x)
                    {
                        first = first.next;
                        second = second.prev;
                    }
                }
            }
        }
        return false;
    }
