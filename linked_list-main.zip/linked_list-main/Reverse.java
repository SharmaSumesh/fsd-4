package com.company;

public class Reverse {
    public class Node
    {
        int data;
        Node next;
        Node(int data)
        {
            this.next = null;
            this.data = data;
        }
    }
    static public Node head= null;
    public void addfirst(int data) {
        Node new_node = new Node(data);
        if(head==null)
        {
            head = new_node;
            return;
        }
        else
        {
            new_node.next = head;
            head = new_node;
        }
    }
    public void reverse()
    {
        Node prev = head;
        Node curr = head.next;
        while (curr!=null)
        {
            Node next  = curr.next;
            curr.next = prev;
            prev = curr;
        }
        head.next = null;
        head = prev;
    }
    public void printlist()
    {
        if(head==null)
        {
            System.out.println("null");
        }
        else {
            Node temp = head;
            while (temp.next != null) {
                System.out.println(temp.data + " ");
                temp = temp.next;
            }

        }    }



    public static void main(String[] args) {
        Reverse a = new Reverse();
        a.addfirst(1);
        a.addfirst(2);
        a.addfirst(3);
        a.addfirst(4);
        a.addfirst(5);
        a.printlist();
        a.reverse();
        a.printlist();


    }
}
