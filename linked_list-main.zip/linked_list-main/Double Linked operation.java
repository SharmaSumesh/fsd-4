package com.company;

public class Double {
    public class Node
    {
        int data;
        Node next;
        Node(int data)
        {
            this.next = null;
          this.data = data;
        }
    }

    public Node head = null;
    public Node tail = null;
    public void addfirst(int data)
    {
        Node new_node = new Node(data);
        if(head==null)
        {
            head = new_node;
            tail = new_node;
        }
        else
        {
            new_node.next = head;
            head = new_node;
            tail.next=new_node;
        }
    }
    public void travere()
    {
        if(head==null)
        {
            System.out.println("empty");
        }
        else
        {
            Node temp  = head;
            while (temp!=null)
            {
                System.out.println(temp.data);
                temp = temp.next;
            }
        }
    }

    public static void main(String[] args) {
        Double a = new Double();
        a.addfirst(1);
        a.addfirst(2);
        a.addfirst(3);
        a.addfirst(4);
        a.travere();

    }
}
